package com.example.androideventbooker;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

public class RecyclerMyEventsAdapter extends RecyclerView.Adapter<RecyclerMyEventsAdapter.MyViewHolder> {

    private ArrayList<Object[]> eventsList;

    public RecyclerMyEventsAdapter(ArrayList<Object[]> eventsList) {

        this.eventsList = eventsList;
        Log.e("RECEIVED EVENT", eventsList.toString());

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        //Can add more fields to recyclerview here
        private TextView eventNameVar;
        private TextView eventDayVar;
        private TextView eventMonthVar;
        private TextView eventVenueVar;
        private TextView eventSportVar;
        private TextView fractionPlayersVar;
        private TextView eventStartToFinishVar;
        public TextView scheduledVar;

        public MyViewHolder(final View view) {

            super(view);

            eventNameVar = view.findViewById(R.id.eventNameText);
            eventDayVar = view.findViewById(R.id.eventDayText);
            eventMonthVar = view.findViewById(R.id.eventMonthText);
            eventSportVar = view.findViewById(R.id.eventSportText);
            fractionPlayersVar = view.findViewById(R.id.fractionPlayersText);
            eventVenueVar = view.findViewById(R.id.eventVenueText);
            eventStartToFinishVar = view.findViewById(R.id.eventStartToFinishText);
            scheduledVar = view.findViewById(R.id.scheduledText);

        }

    }

    @NonNull
    @Override
    public RecyclerMyEventsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_myevents, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerMyEventsAdapter.MyViewHolder holder, int position) {
        Event e = (Event)eventsList.get(position)[0];
        Log.e("ename", e.getEname());
        Boolean j = (Boolean)eventsList.get(position)[1];
        Boolean s = (Boolean)eventsList.get(position)[2];

        String eventName = e.getEname();
        holder.eventNameVar.setText(eventName);

        String [] dateParts = e.getDate().split("-");
        String month = setMonth(dateParts[1]);
        holder.eventDayVar.setText(dateParts[2]);
        holder.eventMonthVar.setText(month);

        String eventSport = e.getSport();
        holder.eventSportVar.setText(eventSport);

        String eventVenue = e.getVenue();
        holder.eventVenueVar.setText(eventVenue);

        String start = e.getStart();
        String end = e.getEnd();
        String startToEnd = start + " - " + end;
        holder.eventStartToFinishVar.setText(startToEnd);

        int numPlayers = e.getNPlayers();
        int maxPlayers = e.getMPlayers();
        String fractionPlayers = "Players: " + numPlayers + " / " + maxPlayers;
        holder.fractionPlayersVar.setText(fractionPlayers);

        holder.scheduledVar.setVisibility(View.VISIBLE);

        if(s&&j)
            holder.scheduledVar.setText("SCHEDULED & JOINED");
        else if(s)
            holder.scheduledVar.setText("SCHEDULED");
        else if(j)
            holder.scheduledVar.setText("JOINED");

    }

    @Override
    public int getItemCount() {
        if(eventsList == null) return 0;
        return eventsList.size();
    }

    public String setMonth(String num) {

        if (num.equals("01"))
            return "JAN";
        else if (num.equals("02"))
            return "FEB";
        else if (num.equals("03"))
            return "MAR";
        else if (num.equals("04"))
            return "APR";
        else if (num.equals("05"))
            return "MAY";
        else if (num.equals("06"))
            return "JUN";
        else if (num.equals("07"))
            return "JUL";
        else if (num.equals("08"))
            return "AUG";
        else if (num.equals("09"))
            return "SEP";
        else if (num.equals("10"))
            return "OCT";
        else if (num.equals("11"))
            return "NOV";
        else if (num.equals("12"))
            return "DEC";
        return num;

    }

}
