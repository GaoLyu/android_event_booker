package com.example.androideventbooker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class ListEvents extends CustomerEvent {

    private DatabaseReference mDatabase;
    private ArrayList<Event> eventList;
    private RecyclerView recyclerView;
    public String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_events);

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.upcoming);
        bottomNavigationView.setOnItemSelectedListener(this);

        eventList = new ArrayList<Event>();
        recyclerView = findViewById(R.id.recyclerV);

        Intent intent = getIntent();
        username = intent.getStringExtra("EXTRA_USERNAME");
        setAdapter();

        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<Event> newEvents = new ArrayList<>();

//                eventList.clear();
                SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                Date date = new Date();
                String currentDate = formatDate.format(date) + "";
                Log.i("date current", formatDate.format(date) + "");
                for(DataSnapshot venueData:dataSnapshot.child("venues").getChildren()){

                    String venueName = venueData.getKey();
                    for(DataSnapshot eventData:dataSnapshot.child(venueName).getChildren()) {
                        Event event = eventData.getValue(Event.class);
                        event.venue = venueName;
                        event.eventNum = eventData.getKey() + "";

                        if(event.getConfirmed() == true){
                            String eventDate = event.getDate() + " " + event.getStart();
                            if(currentDate.compareTo(eventDate) < 0){
                                newEvents.add(event);
                                Collections.sort(newEvents);
                            }
                        }
//                        eventList.add(event);
//                        Collections.sort(eventList);
                       //// Collections.sort(newEvents);
//                        setAdapter();

                    }
                }

                if(eventList.size()== 0 || newEvents.size() != eventList.size()) {
                    eventList = newEvents;
                    setAdapter();
                }
            }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    protected void setAdapter(){
        RecyclerAdapter adapter = new RecyclerAdapter(eventList, username, this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }
}