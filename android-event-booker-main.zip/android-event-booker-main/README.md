# android event booker
 
Notes:

<img width="254" alt="image" src="https://user-images.githubusercontent.com/95906968/184060859-cffc4b66-efb5-4876-89c4-3f2a868a15ca.png">
<img width="251" alt="image" src="https://user-images.githubusercontent.com/95906968/184062328-4b5d0db4-80e1-4e04-b1ff-a66b0b711b52.png">


1. The events scheduled by customers need to be confirmed by admins before showing to the public and showing to themselves. Admins can confirm or unconfirm the events by clicking the events.
2. Multiple events can happen at the same venue at the same time since there are multiple courts in each venue.
