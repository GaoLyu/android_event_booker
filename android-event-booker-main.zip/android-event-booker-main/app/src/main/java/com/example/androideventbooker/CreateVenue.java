package com.example.androideventbooker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateVenue extends AppCompatActivity {

    Venue venue = new Venue();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_venue);

        //Sending checkbox data to database

        CheckBox soccerBox, basketballBox, tennisBox, footballBox, badmintonBox, hockeyBox;

        soccerBox = findViewById(R.id.checkSoccer);
        basketballBox = findViewById(R.id.checkBasketball);
        tennisBox = findViewById(R.id.checkTennis);
        footballBox = findViewById(R.id.checkFootball);
        badmintonBox = findViewById(R.id.checkBadminton);
        hockeyBox = findViewById(R.id.checkHockey);

        addFromCheckBox(soccerBox, "Soccer");
        addFromCheckBox(basketballBox, "Basketball");
        addFromCheckBox(tennisBox, "Tennis");
        addFromCheckBox(footballBox, "Football");
        addFromCheckBox(badmintonBox, "Badminton");
        addFromCheckBox(hockeyBox, "Hockey");

        //Adds data from Create Venue page to Firebase Realtime Database
        Button finish = findViewById(R.id.finish);
        TextInputEditText venueLabel = findViewById(R.id.venue_name);
        TextInputEditText additionalSports = findViewById(R.id.other_sports);

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String venueName = ((TextInputEditText)findViewById(R.id.venue_name)).getText().toString();
                String allSports = ((TextInputEditText)findViewById(R.id.other_sports)).getText().toString();
                venue.name = venueName;

                //Split string to array of strings, then store in database
                String [] splitSports = allSports.split(",\\s*");
                venue.addSports(splitSports);

                if (!((venue.sports).isEmpty()) && !(venue.name).equals("")) {

                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference("venues/" + venue.name);
                    for(String sport: venue.sports)
                        ref.push().setValue(sport);
                    finish();

                }

                //Error proofing
                else {

                    if ((venue.sports).isEmpty())
                        additionalSports.setError("Please select at least one sport");

                    if ((venue.name).equals(""))
                        venueLabel.setError("Please enter a venue name");
                    else if ((venue.name).equals("venues"))
                        venueLabel.setError("Please enter a valid venue name");

                }


            }
        });

    }

    public void addFromCheckBox(CheckBox sportBox, String sport) {

        sportBox.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (sportBox.isChecked()) {
                    (venue.sports).add(sport);
                }
                else {
                    if ((venue.sports).contains(sport)) {
                        (venue.sports).remove(sport);
                    }
                }

            }
        });

    }

}