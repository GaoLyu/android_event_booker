package com.example.androideventbooker;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LogIn extends AppCompatActivity implements View.OnClickListener{

    private TextView register; // for register button
    private TextInputLayout editTextEmail, editTextPassword;
    private Button logIn;

    View v;

    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private FirebaseUser mUser;
    private DatabaseReference reference;

    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();

        // initialising register button
        register = (TextView) findViewById(R.id.register);
        register.setOnClickListener(this); // for register button

        logIn = (Button) findViewById(R.id.logIn);
        logIn.setOnClickListener(this);

        editTextEmail = (TextInputLayout) findViewById(R.id.email);
        editTextPassword = (TextInputLayout) findViewById(R.id.password);

        mAuth = FirebaseAuth.getInstance(); // to initilise Auth
    }

    @Override
    public void onClick(View v) {
        this.v = v;
        switch (v.getId()){ // because we have many cases of clicking buttons
            case R.id.register:
                Pair[] pairs = new Pair[4];
                pairs[0] = new Pair<View, String>(editTextEmail, "tran_email");
                pairs[1] = new Pair<View, String>(editTextPassword, "tran_pass");
                pairs[2] = new Pair<View, String>(logIn, "tran_button");
                pairs[3] = new Pair<View, String>(register, "tran_label");

                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(LogIn.this, pairs);
                startActivity(new Intent(this,RegisterUser.class), options.toBundle());
                break;
            case R.id.logIn:
                userLogin();
                break;
            // where do you wanna go after signing up
        }
    }

    private void userLogin() {
        String email=editTextEmail.getEditText().getText().toString().trim();
        String password = editTextPassword.getEditText().getText().toString().trim();

        if(email.isEmpty()){
            editTextEmail.setError("Email cannot be empty");
            editTextEmail.requestFocus();
            return;
        }
        if (password.isEmpty()){
            editTextPassword.setError("Password cannot be empty ");
            editTextPassword.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("please provide valid email");
            editTextEmail.requestFocus();
            return;
        }
        if (password.isEmpty()){
            editTextPassword.setError("Password cannot be empty");
            editTextPassword.requestFocus();
            return;
        }
        if (password.length()<6){
            editTextPassword.setError("Minimum length of password should be 6 ");
            editTextPassword.requestFocus();
            return;
        }

        // login user in
        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    // retrieve current user and hence redirect based on role
                    user = FirebaseAuth.getInstance().getCurrentUser();
                    reference = FirebaseDatabase.getInstance().getReference("Users");
                    userId= user.getUid();

                    reference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User userProfile = snapshot.getValue(User.class);
                            if (userProfile!=null){
                                if (userProfile.getRole().equals("User")){ // redirect to the user story 3
                                    Intent intent = new Intent(LogIn.this, ListEvents.class);
                                    intent.putExtra("EXTRA_USERNAME", ((TextInputLayout)findViewById(R.id.email)).getEditText().getText().toString());
                                    startActivity(intent);
                                }
                                else
                                {
                                    // redirect to the user story 7
                                    startActivity(new Intent(LogIn.this, EventsByVenue.class));
                                }
                            }
                            else{
                                Toast.makeText(LogIn.this,"Something wrong happend!!!(cannot retrieve data)",Toast.LENGTH_LONG).show();
                            }

                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {}
                    });
                }
                else {
                    // if  user fails to  sign in
                    Snackbar.make(v, "Failed to login, Please chaeck your credentials !!", Snackbar.LENGTH_LONG).show();
                }
            }
        });
    }


}
