package com.example.androideventbooker;

import java.util.HashSet;
import java.util.Set;

public class Venue {

    String name;
    Set<String> sports = new HashSet<String>();

    public Venue () {

    }

    public Venue(String name, Set<String> sports) {

        this.name = name;
        this.sports = sports;

    }

    public void addSports(String [] sp) {

        for (String s: sp) {
            if (!(sports.contains(s))) {
                //Making first letter uppercase, and rest lowercase (for text field user enters sports)
                if(s.length() == 1)
                    sports.add(s.toUpperCase());
                else if(s.length() > 1)
                {
                    String properCase = s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
                    sports.add(properCase);
                }
            }
        }

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<String> getSports() {
        return sports;
    }

    public void setSports(Set<String> sports) {
        this.sports = sports;
    }
}
