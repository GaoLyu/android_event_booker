package com.example.androideventbooker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CustomerSchedule extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    DatePickerDialog datePicker;
    TextInputLayout buttonDate;

    TextInputEditText timeStart, timeEnd;
    int error;




//      Spinner spinnerStart;
//    Spinner spinnerEnd;
    AutoCompleteTextView spinnerSport;
    Button checkButton;
    EditText editTextName;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_schedule);

        Intent intent=getIntent();
        String venue= intent.getExtras().getString("venueName");
        String user=intent.getExtras().getString("EXTRA_USERNAME");
        setTitle(venue);
//        ((TextView)findViewById(R.id.us2textView5)).setText("venue: "+venue);

        editTextName=(EditText)findViewById(R.id.us2editTextTextPersonName);


//        spinnerStart=(Spinner) findViewById(R.id.us2spinner2);
//        ArrayAdapter<CharSequence> adapterStart = ArrayAdapter.createFromResource(this,
//                R.array.startTimeArray, android.R.layout.simple_spinner_item);
//        adapterStart.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinnerStart.setAdapter(adapterStart);
//        spinnerStart.setOnItemSelectedListener(this);
//
//        spinnerEnd=(Spinner) findViewById(R.id.us2spinner3);
//        ArrayAdapter<CharSequence> adapterEnd = ArrayAdapter.createFromResource(this,
//                R.array.endTimeArray, android.R.layout.simple_spinner_item);
//        adapterEnd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinnerEnd.setAdapter(adapterEnd);
//        spinnerEnd.setOnItemSelectedListener(this);

        spinnerSport=(AutoCompleteTextView) findViewById(R.id.us2spinner4);
        ArrayList<String> sportsList=new ArrayList<String>();
        ArrayAdapter<String> adapterSport = new ArrayAdapter<String>(CustomerSchedule.this, R.layout.list_item, sportsList);
        spinnerSport.setAdapter(adapterSport);

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("venues/"+venue);

        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                sportsList.clear();
                for (DataSnapshot node : snapshot.getChildren()) {

                    sportsList.add(node.getValue(String.class));


                }
                adapterSport.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        final Calendar calendar = Calendar.getInstance();
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        datePicker = new DatePickerDialog(CustomerSchedule.this);
        TextInputEditText textViewDate=(TextInputEditText)findViewById(R.id.date_text);

        View.OnClickListener dateListener = (View v) -> { pickDate(textViewDate, calendar, year, month, day); };
        ((TextInputLayout)findViewById(R.id.date)).setOnClickListener(dateListener);
        ((TextInputEditText)findViewById(R.id.date_text)).setOnClickListener(dateListener);
        ((TextInputEditText)findViewById(R.id.date_text)).setOnFocusChangeListener((View view, boolean b) -> {
            if (b) pickDate(textViewDate, calendar, year, month, day);
        });


        timeStart = (TextInputEditText)findViewById(R.id.time_start_text);
        View.OnClickListener startListener = (View v) -> { pickTime("Start Time", 8, 0, R.id.time_start_text); };
        ((TextInputLayout)findViewById(R.id.time_start)).setOnClickListener(startListener);
        timeStart.setOnClickListener(startListener);
        timeStart.setOnFocusChangeListener((View view, boolean b) -> {
            if (b) pickTime("Start Time", 8, 0, R.id.time_start_text);
        });

        timeEnd = (TextInputEditText)findViewById(R.id.time_end_text);
        View.OnClickListener endListener = (View v) -> { pickTime("End Time", 8, 30, R.id.time_end_text); };
        ((TextInputLayout)findViewById(R.id.time_end)).setOnClickListener(endListener);
        timeEnd.setOnClickListener(endListener);
        timeEnd.setOnFocusChangeListener((View view, boolean b) -> {
            if (b) pickTime("End Time", 8, 30, R.id.time_end_text);
        });



        checkButton=(Button)findViewById(R.id.us2button5);
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                error=0;

                String startTime=timeStart.getText().toString();
                String endTime=timeEnd.getText().toString();
                if(textViewDate.getText().toString().equals("")){
                    error=1;
                    Snackbar.make(v, "Please specify what date to be scheduled", Snackbar.LENGTH_LONG).show();
                }
                else if(startTime.equals("")){
                    error=1;
                    Snackbar.make(v, "Please specify the start time", Snackbar.LENGTH_LONG).show();
                }

                else if(endTime.equals("")){
                    error=1;
                    Snackbar.make(v, "Please specify the end time", Snackbar.LENGTH_LONG).show();

                }
                else if(startTime.compareTo(endTime)>=0){
                    error=1;
                    Snackbar.make(v, "The start time must be before the end time, please try again", Snackbar.LENGTH_LONG).show();

                }

                else if(editTextName.getText().toString().equals((""))){
                    error=1;
                    Snackbar.make(v, "Please specify the name of the event", Snackbar.LENGTH_LONG).show();

                }
                else if(spinnerSport.getText().toString().equals("")){
                    error=1;
                    Snackbar.make(v, "Please choose a sport", Snackbar.LENGTH_LONG).show();
                }
                else if(((EditText)findViewById(R.id.us2editTextNumber)).getText().toString().equals("")){
                    error=1;
                    Snackbar.make(v, "Please specify the number of people", Snackbar.LENGTH_LONG).show();
                }




//////////////////////////////////////////////////////////////////////////////////////////////////////////
                if(error==0){
                    //no big problem about format, and we can create the event object
                    //to be continued...



                    String sport=spinnerSport.getText().toString();
                    String date=textViewDate.getText().toString();
                    System.out.println("date is"+date+"sport is"+sport);
                    int peopleNumber=Integer.parseInt(((EditText)findViewById(R.id.us2editTextNumber)).getText().toString());

//                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
//                    String dateString = date+" "+startTime;
//                    Date date2;
//                    time=0;
//                    try {
//                        date2 = sdf.parse(dateString);
//                        time=date2.getTime();
//
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                    }


                    DatabaseReference refVenue = FirebaseDatabase.getInstance().getReference(venue).push();

                    refVenue.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String eventNum=refVenue.getKey();
                            refVenue.child("confirmed").setValue(false);
                            refVenue.child("date").setValue(date);
                            refVenue.child("start").setValue(startTime);
                            refVenue.child("sport").setValue(sport);
                            refVenue.child("end").setValue(endTime);
                            refVenue.child("sport").setValue(sport);
                            refVenue.child("mplayers").setValue(peopleNumber);
                            refVenue.child("scheduler").setValue(user);
                            refVenue.child("ename").setValue(editTextName.getText().toString());
                            refVenue.child("eventNum").setValue(eventNum);
                            refVenue.child("venue").setValue(venue);
                            try{
                                refVenue.child("mstart").setValue(new SimpleDateFormat("yyyy-MM-ddHH:mm").parse(date+startTime).getTime());
                            }catch (ParseException e) {
                                e.printStackTrace();
                            }



                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                    Toast.makeText(getApplicationContext(),"Successfully submitted",Toast.LENGTH_SHORT).show();

                    finish();

                }

            }
        });

    }



    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String item = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    public void back(View view){
        this.finish();
    }




    private void pickDate(TextView textViewDate, Calendar calendar, int year, int month, int day) {
        datePicker = new DatePickerDialog(CustomerSchedule.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
                // adding the selected date in the edittext
                int m=month+1;
                String mon=String.valueOf(m);
                if(m<=9){
                    mon="0"+m;
                }
                String day=String.valueOf(dayOfMonth);
                if(dayOfMonth<=9){
                    day="0"+dayOfMonth;
                }
                textViewDate.setText(year+"-"+ mon + "-" + day);
            }
        }, year, month, day);

        // set maximum date to be selected as today
        datePicker.getDatePicker().setMinDate(calendar.getTimeInMillis());
        datePicker.getDatePicker().setMaxDate(calendar.getTimeInMillis()+(1000*60*60*24*7));

        // show the dialog
        datePicker.show();

    }

    private void pickTime(String title, int hour, int minute, int id) {
        MaterialTimePicker mtp = new MaterialTimePicker.Builder().setTitleText(title).setHour(hour).setMinute(minute).setTimeFormat(TimeFormat.CLOCK_24H).build();
        mtp.addOnPositiveButtonClickListener(cl -> {
            ((TextInputEditText)findViewById(id)).setText(String.format("%02d:%02d", mtp.getHour(), mtp.getMinute()));
        });
        mtp.show(getSupportFragmentManager(), mtp.toString());
    }


}
