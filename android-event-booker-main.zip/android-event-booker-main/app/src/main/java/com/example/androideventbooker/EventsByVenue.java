package com.example.androideventbooker;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.List;

/**
 * User Story 7.
 * Retrieves and displays event data from Firebase Realtime DB based on selected venue.
 * RecyclerView with LinearLayout Manager connected to DB by custom EventByVenueAdapter.
 */
public class EventsByVenue extends AppCompatActivity {
    private final FirebaseDatabase db = FirebaseDatabase.getInstance();
    private FirebaseRecyclerAdapter adapter;
    private RecyclerView recyclerView;
    private AutoCompleteTextView venueSpinner;
    private List<Event> events;

    private static final String RED = "#ed2839";
    private static final String GREEN = "#168d69";

    public class EventViewHolder extends RecyclerView.ViewHolder {
        TextView dateDay, dateMonth, sport, ename, time, playerCount, approved;
        View itemView;
        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemView = itemView;
            dateDay = itemView.findViewById(R.id.dateDay);
            dateMonth = itemView.findViewById(R.id.dateMonth);
            ename = itemView.findViewById(R.id.ename);
            sport = itemView.findViewById(R.id.sport);
            time = itemView.findViewById(R.id.time);
            playerCount = itemView.findViewById(R.id.playerCount);
            approved = itemView.findViewById(R.id.approved);

            ConstraintLayout cl = itemView.findViewById(R.id.admin_events_container);
            View.OnClickListener cc = (View view) -> {
                int idx = getLayoutPosition();
                Event e = events.get(idx);
                if(approved.getText().equals("Confirmed"))
                {
                    approved.setText("Unconfirmed");
                    approved.setTextColor(Color.parseColor(RED));
                    cl.setBackground(getResources().getDrawable(R.drawable.recycle_card_unconfirmed));
                    e.setConfirmed(false);
                }
                else if(approved.getText().equals("Unconfirmed"))
                {
                    approved.setText("Confirmed");
                    approved.setTextColor(Color.parseColor(GREEN));
                    cl.setBackground(getResources().getDrawable(R.drawable.recycle_card_confirmed));
                    e.setConfirmed(true);
                }
                db.getReference(e.venue +"/"+ e.eventNum).setValue(e);
                adapter.notifyItemChanged(idx);
            };
            cl.setOnClickListener(cc);
            approved.setOnClickListener(cc);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_by_venue);

        venueSpinner = findViewById(R.id.spinner);
        recyclerView = findViewById(R.id.recycler1);
        recyclerView.setLayoutManager(new LinearLayoutManager(EventsByVenue.this, LinearLayoutManager.VERTICAL, false));
        FirebaseRecyclerOptions<Event> options = new FirebaseRecyclerOptions.Builder<Event>().setQuery(db.getReference(), Event.class).build();
        adapter = new FirebaseRecyclerAdapter<Event, EventViewHolder>(options) {
            @Override
            public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                // Create a new instance of the ViewHolder, in this case we are using a custom
                // layout called R.layout.event_by_venue for each item
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.event_by_venue, parent, false);
                return new EventViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(EventViewHolder holder, int position, Event model) {
                String[] date = model.getDate().split("-");
                holder.dateDay.setText(date[2]);
                holder.dateMonth.setText((new DateFormatSymbols().getMonths()[Integer.parseInt(date[1])-1]).toString().toUpperCase().substring(0, 3));
                holder.sport.setText(model.getSport());
                holder.ename.setText(model.getEname());
                holder.time.setText(model.getStart() + "-" + model.getEnd());
                holder.playerCount.setText(model.getNPlayers() + "/" + Integer.toString(model.getMPlayers()));

                ConstraintLayout cl = holder.itemView.findViewById(R.id.admin_events_container);
                if(model.getConfirmed()) {
                    holder.approved.setText("Confirmed");
                    holder.approved.setTextColor(Color.parseColor(GREEN));
                    cl.setBackground(getResources().getDrawable(R.drawable.recycle_card_confirmed));
                }
                else {
                    holder.approved.setText("Unconfirmed");
                    holder.approved.setTextColor(Color.parseColor(RED));
                    cl.setBackground(getResources().getDrawable(R.drawable.recycle_card_unconfirmed));
                }
            }
        };
        recyclerView.setAdapter(adapter);

        // STEP 1: set DB Reference to venues.
        DatabaseReference refVenue = db.getReference("venues");
        refVenue.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> venues = new ArrayList<>();
                // STEP 2: record venue name for spinner.
                dataSnapshot.getChildren().forEach(v -> venues.add(v.getKey()));

                // STEP 3: set-up spinner.
                ArrayAdapter<String> areasAdapter = new ArrayAdapter<String>(EventsByVenue.this, R.layout.list_item, venues);
                venueSpinner.setAdapter(areasAdapter);
                venueSpinner.setOnItemClickListener((AdapterView<?> parentView, View selectedItemView, int position, long id) -> {
                    // STEP 4: set list of events when an item im spinner is selected.
                    FirebaseRecyclerOptions<Event> options = new FirebaseRecyclerOptions.Builder<Event>().setQuery(db.getReference().child(venueSpinner.getText().toString()).orderByChild("mstart").startAt(System.currentTimeMillis()), Event.class).build();
                    events = options.getSnapshots();
                    adapter.updateOptions(options);
                    adapter.notifyDataSetChanged();
                    adapter.startListening();
                });
            }
            @Override public void onCancelled(DatabaseError databaseError) { System.out.println("The read failed: " + databaseError.getCode()); }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.venue_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // STEP 5: respond to user clicking new venue "add" button. Connection to User Story 6.
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.newVenue:
                startActivity(new Intent(this, CreateVenue.class)); // TO BE CHANGED TO CONNECT TO USER STORY 6
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}