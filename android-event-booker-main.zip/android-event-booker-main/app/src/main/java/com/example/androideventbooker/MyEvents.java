package com.example.androideventbooker;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MyEvents extends CustomerEvent {

    private ArrayList<Object[]> myEvents;
    private RecyclerView recyclerView;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_events);

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.personal);
        bottomNavigationView.setOnItemSelectedListener(this);


        myEvents = new ArrayList<>();

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        String userEmail = extras.getString("EXTRA_USERNAME");

        DatabaseReference refVenue = FirebaseDatabase.getInstance().getReference("venues");

        refVenue.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot child : snapshot.getChildren()) {
                    
                    String venue = child.getKey();
                    Query q = FirebaseDatabase.getInstance().getReference(venue);
                    q.orderByChild("mstart").startAt(System.currentTimeMillis());

                    q.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            for (DataSnapshot ds: snapshot.getChildren()) {

                                Event e = ds.getValue(Event.class);
                                if(e!=null && e.getConfirmed()) {

                                    boolean j = e.getPlayers() != null && e.getPlayers().contains(userEmail), s = e.getScheduler().equals(userEmail);

                                    if(s||j)
                                        myEvents.add(new Object[]{e, j, s});

                                }
                            }
                            setAdapterMyEvent();
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {}
                    });
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });

    }

    protected void setAdapterMyEvent() {
        recyclerView = findViewById(R.id.recyclerID);
        recyclerView.setLayoutManager(new LinearLayoutManager(MyEvents.this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        if(myEvents != null) {
            myEvents.sort(new Comparator<Object[]>() {
                  @Override
                  public int compare(Object[] objects, Object[] t1) {
                      Event e1 = (Event)objects[0];
                      Event e2 = (Event)t1[0];
                      if (e1.getDate().compareTo(e2.getDate()) > 0) {
                          return 1;
                      } else if (e1.getDate().compareTo(e2.getDate()) < 0) {
                          return -1;
                      } else {
                          return e1.getDate().compareTo(e2.getDate());
                      }
                  }
          });
        }
        recyclerView.setAdapter(new RecyclerMyEventsAdapter(myEvents));
    }
}
