package com.example.androideventbooker;

public class User {

    private String emailAddress;
    private String fullName;
    private String role;

    public User() {}

    // constructor for USer to enter object in the database
//    public User(String email, String fullName, String user){
//
//    }

    public User(String emailAddress, String fullName){

        this.emailAddress=emailAddress;
        this.fullName=fullName;
        this.role="User";

    }

    public String getRole(){
        return this.role;
    }
}
