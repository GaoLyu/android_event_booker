package com.example.androideventbooker;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener{

    // declaring firebase  authentication object
    private FirebaseAuth mAuth;
//    private TextView registerUser;
    private Button registerUser;
    private TextView login;

    private TextInputLayout editTextEmail, editTextPassword , editTextFullName;

//    private TextView back;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        // initialise the auth variable, to get the instance of the database
        mAuth = FirebaseAuth.getInstance();

       registerUser = (Button) findViewById(R.id.registerUser);
       registerUser.setOnClickListener(this); // to instantiate the underlying activity

        login = (TextView) findViewById(R.id.back);
        login.setOnClickListener(this);

       editTextEmail = (TextInputLayout) findViewById(R.id.email);
       editTextPassword=(TextInputLayout) findViewById(R.id.password);
       editTextFullName=(TextInputLayout) findViewById(R.id.fullName);

//        back = (TextView) findViewById(R.id.back);
//        back.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.back:
                Pair[] pairs = new Pair[4];
                pairs[0] = new Pair<View, String>(editTextEmail, "tran_email");
                pairs[1] = new Pair<View, String>(editTextPassword, "tran_pass");
                pairs[2] = new Pair<View, String>(registerUser, "tran_button");
                pairs[3] = new Pair<View, String>(login, "tran_label");

                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(RegisterUser.this, pairs);
                startActivity(new Intent(this,LogIn.class), options.toBundle());
                break;
            case R.id.registerUser:
                registerUser();
                break;
            // redirects after logging in
//            case R.id.back:
//                startActivity(new Intent(this,MainActivity.class));
//                break;
        }

    }

    private  void registerUser(){
        String email = editTextEmail.getEditText().getText().toString().trim();
        String password = editTextPassword.getEditText().getText().toString().trim();
        String fullName = editTextFullName.getEditText().getText().toString().trim();

        if (fullName.isEmpty())
        {
            editTextFullName.setError("Name cannot be empty");
            editTextFullName.requestFocus();
            return;
        }

        // empty email is not allowed
        if (email.isEmpty())
        {
            editTextEmail.setError("Email cannot be empty");
            editTextEmail.requestFocus();
            return;
        }

        // empty password is not allowed
        if (password.isEmpty()){
            editTextPassword.setError("Password cannot be empty");
            editTextPassword.requestFocus();
            return;
        }

        // if email string does not matches the regex for email
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("please provide valid email");
            editTextEmail.requestFocus();
            return;
        }

        // password is not of length 6 because firebase gives an error on less than 6 characters
        if (password.length()<6){
            editTextPassword.setError("Minimum length of password should be 6 ");
            editTextPassword.requestFocus();
            return;
        }

        // creating authentication object , user object and storing it into database
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        // if the user has been registered
                        if(task.isSuccessful()){
                             User user  = new User(email,fullName);
                             // send user object to the database
                             FirebaseDatabase.getInstance().getReference("Users")   // name of collection is user
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())    // so that we correspond to the registered user ->returns id of the registered user
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                         @Override
                                         public void onComplete(@NonNull Task<Void> task) {

                                             // if the user has been registered and data is inserted in the database
                                             if(task.isSuccessful()){
                                                 Toast.makeText(RegisterUser.this,"User has been registered successfully",Toast.LENGTH_LONG).show();
                                                 // redirect to next page
                                                 Intent intent = new Intent(RegisterUser.this,ListEvents.class);
                                                 intent.putExtra("EXTRA_USERNAME", ((TextInputLayout)findViewById(R.id.email)).getEditText().getText().toString());
                                                 startActivity(intent);
                                             }
                                             else {
                                                 Toast.makeText(RegisterUser.this,"Failed to register!! Try again",Toast.LENGTH_LONG).show();
                                             }
                                         }
                                     });
                        }

                        else
                        {
                            Toast.makeText(RegisterUser.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
//                            Toast.makeText(RegisterUser.this,"Failed to register!! Try again",Toast.LENGTH_LONG).show();
                        }
                    }
                });





    }
}