package com.example.androideventbooker;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.navigation.NavigationBarView;

/**
 * Abstract class inherited by the 3 customer pages: schedule event, upcoming events, personal events to
 * add bottom navigation.
 */
public abstract class CustomerEvent extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener{
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        switch (item.getItemId()) {
            case R.id.schedule:
                Intent customerVenue=new Intent(this, CustomerVenSports.class);
                customerVenue.putExtras(extras);
                startActivity(customerVenue);

                overridePendingTransition(0,0);
                return true;

            case R.id.upcoming:
                Intent listEvents=new Intent(this, ListEvents.class);
                listEvents.putExtras(extras);
                startActivity(listEvents);

                overridePendingTransition(0,0);
                return true;

            case R.id.personal:
                Intent myEvents =new Intent(this, MyEvents.class);
                myEvents.putExtras(extras);
                startActivity(myEvents);

                overridePendingTransition(0,0);
                return true;
        }
        return false;
    }

}
