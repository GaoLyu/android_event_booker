package com.example.androideventbooker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>{
    private ArrayList<Event> eventList;
    public String username;
    public ListEvents listEvent;

    public RecyclerAdapter(ArrayList<Event> eventList, String username, ListEvents listEvent){
        this.eventList = eventList;
        this.username = username;
        this.listEvent = listEvent;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView venueTxt;
        private TextView monthTxt;
        private TextView dayTxt;
        private TextView startTxt;
        private TextView endTxt;
        private TextView sportTxt;
        private TextView mplayersTxt;
        private TextView enameTxt;
        private TextView statusTxt;



        public MyViewHolder(final View view){
            super(view);
            venueTxt = view.findViewById(R.id.venue_list_events);
            monthTxt = view.findViewById(R.id.month_list_events);
            dayTxt = view.findViewById(R.id.day_list_events);
            startTxt = view.findViewById(R.id.start_list_events);
            endTxt = view.findViewById(R.id.end_list_events);
            sportTxt = view.findViewById(R.id.sport_list_events);
            mplayersTxt = view.findViewById(R.id.mplayers_list_events);
            enameTxt = view.findViewById(R.id.event_name_list_events);
            statusTxt = view.findViewById((R.id.availability_list_events));

            itemView.findViewById(R.id.join_btn_list_events).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int index = getLayoutPosition();
                    Event updatedEvent = eventList.get(index);
                    if(updatedEvent.getPlayers() == null){
                        ArrayList<String> playerList = new ArrayList<String>();
                        playerList.add(username);
                        updatedEvent.setPlayers(playerList);
                    }
                    else {
                        updatedEvent.getPlayers().add(username);
                    }

                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();

                    ref.child(updatedEvent.venue).child(updatedEvent.eventNum).setValue(updatedEvent);
                    notifyItemChanged(index);
                    Toast.makeText(listEvent.getApplicationContext(), "Event joined!", Toast.LENGTH_SHORT).show();
                }
            });

        }
    }

    @NonNull
    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_events_interface, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {
      //  String status = " - ";
        String status = "";
        int statusUsed = 0;
        int curNumPlayers = 0;
        if(eventList.get(position).getPlayers() != null){
            curNumPlayers = eventList.get(position).getPlayers().size();
            if(eventList.get(position).getPlayers().contains(username)){
                status = status + "Registered";
                statusUsed = 1;
                holder.itemView.findViewById(R.id.join_btn_list_events).setEnabled(false);
            }
        }
        if(curNumPlayers >= eventList.get(position).getMPlayers()){
            if(statusUsed == 1){
                status = "Registered - Fully Booked";
            }
            else {
                status = status + "Fully Booked";
            }
            statusUsed = 1;
            holder.itemView.findViewById(R.id.join_btn_list_events).setEnabled(false);
        }
        if(statusUsed == 0){
            status = status +  (eventList.get(position).getMPlayers() - curNumPlayers) + " Spot(s) Available";
            holder.itemView.findViewById(R.id.join_btn_list_events).setEnabled(true);
        }

        String venueStr = eventList.get(position).getVenue();
        holder.venueTxt.setText(venueStr);
        String dateArray[] = eventList.get(position).getDate().split("-");

        String[] months = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP",
                "OCT", "NOV", "DEC"};

        String monthStr = months[Integer.parseInt(dateArray[1]) - 1];
        holder.monthTxt.setText(monthStr);
        String dayStr = dateArray[2];
        holder.dayTxt.setText(dayStr);
        String startStr = eventList.get(position).getStart();
        holder.startTxt.setText(startStr);
        String endStr = eventList.get(position).getEnd();
        holder.endTxt.setText(endStr);
        String sportStr = eventList.get(position).getSport();
        holder.sportTxt.setText(sportStr);
        String mplayersStr = eventList.get(position).getMPlayers() + "";
        holder.mplayersTxt.setText(mplayersStr);
        String enameStr = eventList.get(position).getEname() + "";
        holder.enameTxt.setText(enameStr);
        holder.statusTxt.setText(status);



    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }


}
