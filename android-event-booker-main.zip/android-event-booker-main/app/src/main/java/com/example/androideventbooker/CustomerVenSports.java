package com.example.androideventbooker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CustomerVenSports extends CustomerEvent {

    DatabaseReference dbref;
    AutoCompleteTextView spinner;
    ArrayList<String> venueList=new ArrayList<String>();
    ArrayAdapter<String> adapter;
    Button buttonSchedule;
    TextView textVenue;
    ListView listview;
    List<String> sportsList=new ArrayList<String>();
    ArrayAdapter<String> adapter2;
    DatabaseReference dbref2;
    String venue;
    int hasSport;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_ven_sports);

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.schedule);
        bottomNavigationView.setOnItemSelectedListener(this);


        Intent thisIntent = getIntent();
        Bundle extras = thisIntent.getExtras();
        listview=(ListView) findViewById(R.id.us2lv);
        textVenue=(TextView)findViewById(R.id.us2textView30);
        buttonSchedule=(Button) findViewById(R.id.us2button20);
        spinner = (AutoCompleteTextView) findViewById(R.id.us2s3);

        adapter = new ArrayAdapter<>(this, R.layout.list_item, venueList);
        spinner.setAdapter(adapter);
        spinner.setOnItemClickListener((AdapterView<?> parentView, View v, int position, long id) -> {
            venue=String.valueOf(spinner.getText());
            textVenue.setText("Sports available at venue: \n"+venue);
            adapter2 = new ArrayAdapter<String>(CustomerVenSports.this, android.R.layout.simple_list_item_1, sportsList);
            listview.setAdapter(adapter2);

            dbref2 = FirebaseDatabase.getInstance().getReference("venues/"+venue);
            //Toast.makeText(getApplicationContext(),venue,Toast.LENGTH_SHORT).show();

            dbref2.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    hasSport=0;
                    sportsList.clear();
                    if(!(snapshot.hasChildren())){
                        sportsList.add("There is no sport available.");
                        hasSport=-1;
                    }
                    else{
                        for (DataSnapshot node : snapshot.getChildren()) {
                            sportsList.add(node.getValue(String.class));
                        }
                    }

                    adapter2.notifyDataSetChanged();
                }

                @Override public void onCancelled(@NonNull DatabaseError error) {}
            });

        });



        dbref = FirebaseDatabase.getInstance().getReference("venues");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                venueList.clear();
                for (DataSnapshot node : snapshot.getChildren()) {
                    venueList.add(node.getKey());
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });



        buttonSchedule.setOnClickListener((View v) -> {
            if(hasSport==-1) {
                Snackbar.make(v, "Please select another venue since there is no sport available at present", Snackbar.LENGTH_LONG).show();
            }
            else if(String.valueOf(spinner.getText()).equals("")){
                Snackbar.make(v, "Please select a venue", Snackbar.LENGTH_LONG).show();
            }
            else{
                Intent intent= new Intent(CustomerVenSports.this,CustomerSchedule.class);
                extras.putString("venueName",String.valueOf(spinner.getText()));
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
    }
}
