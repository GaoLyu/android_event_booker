package com.example.androideventbooker;

import java.util.List;

public class Event implements Comparable<Event> {
    private String ename;
    private String date;
    private String sport;
    private String start;
    private String end;
    private int mplayers;
    private long mstart;
    public String eventNum;
    public String venue;
    private List<String> players;
    private String scheduler;
    private Boolean confirmed;

    public Event() {}

    @Override
    public int compareTo(Event e) {
        if (this.date.compareTo(e.date) > 0) {
            return 1;
        } else if (this.date.compareTo(e.date) < 0) {
            return -1;
        } else {
            return this.start.compareTo(e.start);
        }
    }

    public String getEname() { return ename; }
    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    public String getSport() {
        return sport;
    }
    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getStart() {
        return start;
    }
    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }
    public void setEnd(String end) {
        this.end = end;
    }

    public int getMPlayers() {
        return mplayers;
    }
    public void setMPlayers(int mplayers) {
        this.mplayers = mplayers;
    }

    public long getMstart() { return mstart; }
    public void setMstart(long mstart) { this.mstart = mstart; }

    public String getEventNum() { return eventNum; }
    public void setEventNum(String eventNum) { this.eventNum = eventNum; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public List<String> getPlayers() {
        return players;
    }
    public void setPlayers(List<String> players) {
        this.players = players;
    }

    public int getNPlayers() {
        return players == null ? 0 : players.size();
    }

    public String getScheduler() {
        return scheduler;
    }

    public void setScheduler(String scheduler) {
        this.scheduler = scheduler;
    }

    public Boolean getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(Boolean confirmed) {
        this.confirmed = confirmed;
    }

}
